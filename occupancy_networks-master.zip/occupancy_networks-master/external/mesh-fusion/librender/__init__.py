import ctypes
import os

#pyrender_dir = os.path.dirname(os.path.realpath(__file__))
#ctypes.cdll.LoadLibrary(os.path.join(pyrender_dir, 'pyrender.so'))
from librender.pyrender import *
